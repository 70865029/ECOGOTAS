package com.ecogota.appp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class RegistroEmail : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registro_email)
    }
}